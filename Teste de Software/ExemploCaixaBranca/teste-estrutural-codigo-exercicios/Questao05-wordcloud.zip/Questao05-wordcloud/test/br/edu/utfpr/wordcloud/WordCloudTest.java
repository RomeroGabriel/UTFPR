package br.edu.utfpr.wordcloud;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class WordCloudTest {

	@Test
	public void test01() {
		String textoInicial = "Nuvem de palavras, word cloud, � uma imagem compostas de palavras usadas em "
				+ "um texto ou assunto espec�fico no qual o tamanho de cada palavra indica sua frequ�ncia. A "
				+ "nuvem de palavras pode ser constru�da da seguinte forma. Transformar o texto original em um array "
				+ "de strings no qual cada elemento do array � uma palavra. Neste caso, espa�os em branco, pontos finais e v�rgulas "
				+ "s�o desconsiderados. Remover deste array palavras que n�o s�o de interesse, est�o contidas em uma lista negra. Exemplos de"
				+ " palavras que poderiam estar em uma lista negra s�o artigos, preposi��es, adv�rbios, etc. Contar e armazenar a frequ�ncia "
				+ "de cada palavra. Ordenar, de forma decrescente, as palavras pela frequ�ncia. Gerar a imagem dando destaque as "
				+ "palavras com maior frequ�ncia.";
		
		WordCloud wcloud = new WordCloud();
		wcloud.setInitialText(textoInicial);
		
		List<String> blackList = Arrays.asList("a", "de", "uma", "em");
		
		wcloud.setBlackList( blackList );
		ArrayList<Frequency> frequencies = wcloud.getOrderedFrequencies();
		
		Frequency previous = new Frequency("AA", Integer.MAX_VALUE);
		for (Frequency current : frequencies) {
			assertTrue(previous.getCount() >= current.getCount());
			
			System.out.println(current);
			previous = current;
		}
	}
}