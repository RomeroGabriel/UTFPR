package br.edu.utfpr.wordcloud;

public class Frequency implements Comparable<Frequency> {
	private String word;
	private int count;
	
	public Frequency(String pWord, int pCount) {
		word = pWord;
		count = pCount;
	}
	
	public int getCount() {
		return count;
	}
	public String getWord() {
		return word;
	}
	
	@Override
	public String toString() {
		return "<" + word + "," + count + ">";
	}

	@Override
	public int compareTo(Frequency otherFreq) {
		if(this.getCount() < otherFreq.getCount())
			return +1;
		else if(this.getCount() == otherFreq.getCount())
			return 0;
		
		return -1;
	}
}
