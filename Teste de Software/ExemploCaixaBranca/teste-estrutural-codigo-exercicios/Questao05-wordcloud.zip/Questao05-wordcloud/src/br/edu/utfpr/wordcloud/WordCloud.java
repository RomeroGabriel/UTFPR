package br.edu.utfpr.wordcloud;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class WordCloud {
	private List<String> blackList = new ArrayList<String>();
	private ArrayList<String> cWords;
	
	public void setInitialText(String initialText) {
		//replace all ',' and '.' by ' '
		initialText = initialText.replaceAll(",", " ");
		initialText = initialText.replaceAll("\\.", " ");
		
		cWords = getWords(initialText);				
	}

	private void removeWordsFromBlackList(ArrayList<String> cWords) {
		for (Iterator<String> iterator = cWords.iterator(); iterator.hasNext();) {
			String word = iterator.next();
			if(blackList.contains(word))
				iterator.remove();
		}		
	}

	private ArrayList<String> getWords(String initialText) {
		ArrayList<String> retWords = new ArrayList<String>();
		
		String words[] = initialText.split(" ");
		for(String word : words) {
			word = word.trim();
			if(! word.equals("")) 
				retWords.add( word.toLowerCase() );
		}
		return retWords;
	}

	public void setBlackList(List<String> blackList) {
		this.blackList  = blackList;
	}

	public ArrayList<Frequency> getOrderedFrequencies() {
		removeWordsFromBlackList(cWords);

		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for (String word : cWords) {
			if(map.get(word) == null)
				map.put(word, new Integer(0));
			
			int count = map.get(word);
			map.put(word, new Integer(++count));
		}
		
		ArrayList<Frequency> frequencies = mapToFrequencies(map);
		//sort the  frequencies
		Collections.sort(frequencies);
		
		return frequencies;
	}

	private ArrayList<Frequency> mapToFrequencies(HashMap<String, Integer> map) {
		ArrayList<Frequency> retFrequencies = new ArrayList<Frequency>();
		
		for (Entry<String, Integer> e : map.entrySet()) {
			Frequency f = new Frequency(e.getKey(), e.getValue());
			retFrequencies.add( f );
		}
		return retFrequencies;
	}
}