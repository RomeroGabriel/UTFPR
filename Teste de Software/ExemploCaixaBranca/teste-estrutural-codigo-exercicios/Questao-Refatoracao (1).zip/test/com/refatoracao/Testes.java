package com.refatoracao;

import com.refatoracao.Cliente;
import com.refatoracao.Filme;
import com.refatoracao.Locacao;
import org.junit.Test;
import static org.junit.Assert.*;

public class Testes {
    
    public Testes() {
    }
    @Test
    public void teste01() {
        Filme f1 = new Filme("Ben Hur", Filme.NORMAL);
        Filme f2 = new Filme("Galinha Pintadinha", Filme.CRIANCA);
        Filme f3 = new Filme("Star Wars VII", Filme.LANCAMENTO);
        
        Locacao l1 = new Locacao(f1, 3);
        Locacao l2 = new Locacao(f2, 5);
        Locacao l3 = new Locacao(f3, 2);
        
        Cliente c1 = new Cliente("Joao da Silva");
        c1.adicionarLocacao(l1);
        c1.adicionarLocacao(l2);
        c1.adicionarLocacao(l3);
        
        c1.imprimirSumario();
    } 
}
