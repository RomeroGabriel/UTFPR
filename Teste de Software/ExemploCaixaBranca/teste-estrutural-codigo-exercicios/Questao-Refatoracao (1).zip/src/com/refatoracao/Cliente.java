package com.refatoracao;

import java.util.ArrayList;

public class Cliente {
    private String nome;
    private ArrayList<Locacao> locacoes = new ArrayList<Locacao>();
    
    public Cliente(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }
    public void adicionarLocacao(Locacao locacao) {
        locacoes.add(locacao);
    }
    /**
     * metodo percorre todas as locacoes do cliente e imprimi
     * um sumario sobre o custo total da locacao e total de pontos
     * obtidos pelo cliente. 
     * 
     * Cada tipo de filme tem um custo e ha uma condicao especial
     * no qual um ponto extra eh ganho.
     */
    public void imprimirSumario() {
        int pontos = 0;
        float custoTotalLocacao = 0;
        
        String toPrint = "Sumario de locacao de " + nome + "\n";
        for(Locacao l : locacoes) {
            //custo individual 
            float custoIndividual = 0;
            switch(l.getFilme().getPrecoCodigo()) {
                case Filme.NORMAL:
                    custoIndividual += 2;
                    if(l.getDias_alugado() > 2)
                        custoIndividual += (l.getDias_alugado() - 2) * 1.5;
                    break;
                case Filme.LANCAMENTO:
                    custoIndividual += l.getDias_alugado() * 3;
                    break;
                case Filme.CRIANCA:
                    custoIndividual += 1.5;
                    if(l.getDias_alugado() > 3)
                        custoIndividual += (l.getDias_alugado() - 3) * 1.5;                    
                    break;                    
            }
            
            //calculo de pontos
            pontos += 1;
            //bonus para locacao de lancamento por 2 dias ou mais
            if(l.getFilme().getPrecoCodigo() == Filme.LANCAMENTO 
                    && l.getDias_alugado() > 1)
                pontos += 1;
            
            toPrint += "\t" + l.getFilme().getTitulo() + "\t" +
                    custoIndividual + "\n";
            
            custoTotalLocacao += custoIndividual;
        }
        toPrint += "total devido: " + custoTotalLocacao + "\n";
        toPrint += "ganhou " + pontos + " pontos.\n";
        System.out.println(toPrint);
    }
}