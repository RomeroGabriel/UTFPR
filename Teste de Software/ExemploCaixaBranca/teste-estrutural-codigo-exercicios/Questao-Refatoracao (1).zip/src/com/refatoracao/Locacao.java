package com.refatoracao;

public class Locacao {
    private Filme filme;
    private int dias_alugado;

    public Locacao(Filme filme, int dias_alugado) {
        this.filme = filme;
        this.dias_alugado = dias_alugado;
    }
    public Filme getFilme() {
        return filme;
    }
    public int getDias_alugado() {
        return dias_alugado;
    }
}