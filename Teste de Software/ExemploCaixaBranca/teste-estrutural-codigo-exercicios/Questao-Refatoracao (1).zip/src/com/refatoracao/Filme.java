package com.refatoracao;

public class Filme {
    public static final int NORMAL = 0;
    public static final int LANCAMENTO = 1;
    public static final int CRIANCA = 2;
    
    private String titulo;
    private int precoCodigo;
    
    public Filme(String titulo, int precoCodigo) {
        this.titulo = titulo;
        this.precoCodigo = precoCodigo;
    }
    public String getTitulo() {
        return titulo;
    }
    public int getPrecoCodigo() {
        return precoCodigo;
    }
}