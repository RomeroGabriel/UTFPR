package br.edu.utfpr.knn;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import ponto.Ponto;
import ponto.PontoDistanceCalculator;

/**
 * 
 * @author andreendo
 *
 */
public class KNNTest {

	@Test
	public void test01() {
		
		ArrayList<Ponto> pontos = new ArrayList<>();
		pontos.add( new Ponto(0, 0) );
		pontos.add( new Ponto(-1.5, 3) );
		pontos.add( new Ponto(10, 10) );
		pontos.add( new Ponto(110, 120) );
		pontos.add( new Ponto(1.2, 1.1) );
		pontos.add( new Ponto(10, 10) );
		pontos.add( new Ponto(11, 11) );
		pontos.add( new Ponto(1, 20) );		
		pontos.add( new Ponto(110, 120) );
		
		Ponto referencia = new Ponto(1.1, 1.1);
		
		KNN<Ponto> knn = new KNN<Ponto>();
		knn.setList(pontos);
		knn.setDistanceCalculator( new PontoDistanceCalculator() );
		knn.setReference(referencia);
		
		ArrayList<Ponto> neighbors = knn.getKNearestNeighbors( 3 );
		assertEquals(3, neighbors.size());
		System.out.println( neighbors );
		assertTrue( neighbors.get(0).equals( new Ponto(1.2, 1.1) ) );
		assertTrue( neighbors.get(1).equals( new Ponto(0, 0) ) );
		assertTrue( neighbors.get(2).equals( new Ponto(-1.5, 3) ) );
	}
	
	@Test
	public void test02() {
		//create a different class and distance calculator and test here!
	}	
}
