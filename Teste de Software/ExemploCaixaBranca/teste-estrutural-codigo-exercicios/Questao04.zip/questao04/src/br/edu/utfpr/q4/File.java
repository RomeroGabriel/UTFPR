package br.edu.utfpr.q4;

public class File extends Element {

	String extension;
	
	public File(String filename, String fileextension) {
		this.name = filename;
		this.extension = fileextension;
	}
	
	@Override
	public String getPath() {
		if(getParent() == null)
			return name + "." + extension;
		
		return getParent().getPath() + "//" + name + "." + extension;  
	}
	
	public String getExtension() {
		return extension;
	}
	
	public void setExtension(String extension) {
		this.extension = extension;
	}
}
