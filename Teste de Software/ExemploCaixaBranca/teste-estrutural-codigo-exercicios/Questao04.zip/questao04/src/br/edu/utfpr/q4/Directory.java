package br.edu.utfpr.q4;

import java.util.ArrayList;

public class Directory extends Element {
	
	ArrayList<Element> children = new ArrayList<>();
	
	public Directory(String dirname) {
		this.name = dirname;
	}
	
	//composite
	public void add(Element e) {
		children.add(e);
		
		//keep track of the parent
		e.setParent(this);
	}
	
	@Override
	public String getPath() {
		if(getParent() == null)
			return name;
		
		return getParent().getPath() + "//" + name;  
	}
}
