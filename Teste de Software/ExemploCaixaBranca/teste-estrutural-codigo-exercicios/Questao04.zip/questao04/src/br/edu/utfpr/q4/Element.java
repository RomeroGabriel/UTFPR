package br.edu.utfpr.q4;

public abstract class Element {
	Element parent = null;
	String name;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setParent(Element parent) {
		this.parent = parent;
	}
	
	public Element getParent() {
		return parent;
	}
	
	public abstract String getPath();
}
