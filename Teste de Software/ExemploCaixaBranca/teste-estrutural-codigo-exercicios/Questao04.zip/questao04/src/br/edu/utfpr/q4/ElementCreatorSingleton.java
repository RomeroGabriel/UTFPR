package br.edu.utfpr.q4;

//singleton
public class ElementCreatorSingleton {

	public static final int DIR = 1;
	public static final int FILE = 2;
	private static ElementCreatorSingleton instance = null;
	
	private ElementCreatorSingleton() {	}
	
	public static synchronized ElementCreatorSingleton getInstance() {
		if(instance == null) 
			instance = new ElementCreatorSingleton();
		
		return instance;
	}

	//factory method
	public Element make(int type, String name) {
		if(type == DIR)
			return new Directory(name);
		
		if(type == FILE) {
			String s[] = name.split("#");
			if(s.length >= 2)
				return new File(s[0], s[1]);
			else
				return new File(s[0], "");
		}
		
		return null;
	}
	
}
