package br.edu.utfpr.q4;

import org.junit.Test;

public class Tests {

	@Test
	public void test() {
		ElementCreatorSingleton creator = ElementCreatorSingleton.getInstance();
		Directory so = (Directory) creator.make(ElementCreatorSingleton.DIR, "SO");
		File agendatxt = (File) creator.make(ElementCreatorSingleton.FILE, "agenda#txt");
		
		Directory aulas = (Directory) creator.make(ElementCreatorSingleton.DIR, "aulas");
		File arquivostxt = (File) creator.make(ElementCreatorSingleton.FILE, "arquivos#txt");
		File memoriatxt = (File) creator.make(ElementCreatorSingleton.FILE, "memoria#txt");
		File processotxt = (File) creator.make(ElementCreatorSingleton.FILE, "processos#txt");
		
		Directory exemplos = (Directory) creator.make(ElementCreatorSingleton.DIR, "exemplos");
		File linuxtxt = (File) creator.make(ElementCreatorSingleton.FILE, "linux#txt");
		File windowstxt = (File) creator.make(ElementCreatorSingleton.FILE, "windows#txt");
		
		so.add(aulas);
		so.add(agendatxt);
		so.add(exemplos);
		
		aulas.add(arquivostxt);
		aulas.add(memoriatxt);
		aulas.add(processotxt);
		
		exemplos.add(linuxtxt);
		exemplos.add(windowstxt);
		
		System.out.println(so.getPath());
		System.out.println(aulas.getPath());
		System.out.println(agendatxt.getPath());
		System.out.println(exemplos.getPath());
		
		System.out.println(arquivostxt.getPath());
		System.out.println(memoriatxt.getPath());
		System.out.println(processotxt.getPath());
		System.out.println(linuxtxt.getPath());
		System.out.println(windowstxt.getPath());
	}

}
